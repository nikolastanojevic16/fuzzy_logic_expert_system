import java.awt.EventQueue;
import net.sourceforge.jFuzzyLogic.*;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Test {

	private JFrame frame;
	private JLabel lblNaslov;
	private JLabel lblOpis;
	private JButton btnStart;
	private JPanel panel, panel1;
	public JButton[] button_Next;
	private JLabel lblPitanja;
	private JLabel lblNewLabel;
	private JTextField txtOcena;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test window = new Test();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public void Change(int status)
	{
		
		///////////////////////////////////
		// SPORT
		//////////////////////////////////
		
		if(status==0) 
		{
			button_Next[0].setVisible(true);
			button_Next[47].setVisible(false);
			button_Next[0].setText("Next");
			this.lblPitanja.setText("1. Ve�bam i treniram svakodnevno.");
		}
		
		if(status==1) 
		{
			button_Next[0].setVisible(false);
			button_Next[1].setVisible(true);
			button_Next[1].setText("Next");
			this.lblPitanja.setText("2. Pokre�e me adrenalin.");
		}
		
		if(status==2) 
		{
			button_Next[1].setVisible(false);
			button_Next[2].setVisible(true);
			button_Next[2].setText("Next");
			this.lblPitanja.setText("3. Uzivao/la bih u ovacijama i aplauzima publike.");
		}
		
		if(status==3) 
		{
			button_Next[2].setVisible(false);
			button_Next[3].setVisible(true);
			button_Next[3].setText("Next");
			this.lblPitanja.setText("4. U�ivam u takmi�enjima.");
		}
		
		if(status==4) 
		{
			button_Next[3].setVisible(false);
			button_Next[4].setVisible(true);
			button_Next[4].setText("Next");
			this.lblPitanja.setText("5. Sposoban/a sam da izdr�im kada je najte�e.");
		}
		
		if(status==5) 
		{
			button_Next[4].setVisible(false);
			button_Next[5].setVisible(true);
			button_Next[5].setText("Next");
			this.lblPitanja.setText("6. Redovno pratim i pose�ujem sportske doga�aje.");
		}
		
///////////////////////////////////
// UMETNOST
//////////////////////////////////
		
		if(status==6) 
		{
			button_Next[5].setVisible(false);
			button_Next[6].setVisible(true);
			button_Next[6].setText("Next");
			this.lblPitanja.setText("7. U�ivam u dizajniranju razli�itih predmeta.");
		}
		
		if(status==7) 
		{
			button_Next[6].setVisible(false);
			button_Next[7].setVisible(true);
			button_Next[7].setText("Next");
			this.lblPitanja.setText("8. Prija mi da ispoljavam svoju kreaticnost kroz slikanje i pisanje.");
		}
		
		if(status==8) 
		{
			button_Next[7].setVisible(false);
			button_Next[8].setVisible(true);
			button_Next[8].setText("Next");
			this.lblPitanja.setText("9. Moj cilj je da budem originalan/a i druga�iji/a od ostalih.");
		}
		
		if(status==9) 
		{
			button_Next[8].setVisible(false);
			button_Next[9].setVisible(true);
			button_Next[9].setText("Next");
			this.lblPitanja.setText("10. Volim da pravim figure od gline i sli�nih materijala.");
		}
		
		if(status==10) 
		{
			button_Next[9].setVisible(false);
			button_Next[10].setVisible(true);
			button_Next[10].setText("Next");
			this.lblPitanja.setText("11. Imam smisla za ure�ivanje enterijera.");
		}
		
		if(status==11) 
		{
			button_Next[10].setVisible(false);
			button_Next[11].setVisible(true);
			button_Next[11].setText("Next");
			this.lblPitanja.setText("12. U�ivam u fotografisanju i snimanju razli�itih doga�aja.");
		}
		
///////////////////////////////////
// DRUSTVENE NAUKE
//////////////////////////////////
		
		if(status==12) 
		{
			button_Next[11].setVisible(false);
			button_Next[12].setVisible(true);
			button_Next[12].setText("Next");
			this.lblPitanja.setText("<html>13. U�ivao/la bih u profesiji koja podrazumeva savetovanje drugih kako da re�e svoje probleme.</html>");
		}
		
		if(status==13) 
		{
			button_Next[12].setVisible(false);
			button_Next[13].setVisible(true);
			button_Next[13].setText("Next");
			this.lblPitanja.setText("14.U�ivam u �itanju istorije.");
		}
		
		if(status==14) 
		{
			button_Next[13].setVisible(false);
			button_Next[14].setVisible(true);
			button_Next[14].setText("Next");
			this.lblPitanja.setText("15. Volim da organizujem vreme i na�in obaljanja poslova.");
		}
		
		if(status==15) 
		{
			button_Next[14].setVisible(false);
			button_Next[15].setVisible(true);
			button_Next[15].setText("Next");
			this.lblPitanja.setText("16. U�ivam u u�enju drugih stranih jezika. ");
		}
		
		if(status==16) 
		{
			button_Next[15].setVisible(false);
			button_Next[16].setVisible(true);
			button_Next[16].setText("Next");
			this.lblPitanja.setText("17. Zanimljiva mi je ljudska psiha i na�in na koji funkcioni�e.");
		}
		
		if(status==17) 
		{
			button_Next[16].setVisible(false);
			button_Next[17].setVisible(true);
			button_Next[17].setText("Next");
			this.lblPitanja.setText("18. Kriti�ki razmi�ljam o stvarima koje vidim, �ujem ili pro�itam.");
		}
	
///////////////////////////////////
// TEHNIKA
//////////////////////////////////
		
		if(status==18) 
		{
			button_Next[17].setVisible(false);
			button_Next[18].setVisible(true);
			button_Next[18].setText("Next");
			this.lblPitanja.setText("19. Veoma dobro poznajem rad u razli�itim kompjuterskim programima.");
		}
		
		if(status==19) 
		{
			button_Next[18].setVisible(false);
			button_Next[19].setVisible(true);
			button_Next[19].setText("Next");
			this.lblPitanja.setText("20. Lako mi je da zamislim kako planovi i skice izgledaju u stvarnosti.");
		}
		
		if(status==20) 
		{
			button_Next[19].setVisible(false);
			button_Next[20].setVisible(true);
			button_Next[20].setText("Next");
			this.lblPitanja.setText("21. Roborika je veoma interesantna oblast.");
		}
		
		if(status==21) 
		{
			button_Next[20].setVisible(false);
			button_Next[21].setVisible(true);
			button_Next[21].setText("Next");
			this.lblPitanja.setText("22. Interesuje me kako funkcioni�u razli�iti aparati i ure�aji.");
		}
		
		if(status==22) 
		{
			button_Next[21].setVisible(false);
			button_Next[22].setVisible(true);
			button_Next[22].setText("Next");
			this.lblPitanja.setText("23. Volim da rukujem alatom.");
		}
		
		if(status==23) 
		{
			button_Next[22].setVisible(false);
			button_Next[23].setVisible(true);
			button_Next[23].setText("Next");
			this.lblPitanja.setText("24. Ra�unarstvo mi ide od ruke.");
		}
		
///////////////////////////////////
// PRIRODNE NAUKE
//////////////////////////////////
		
		if(status==24) 
		{
			button_Next[23].setVisible(false);
			button_Next[24].setVisible(true);
			button_Next[24].setText("Next");
			this.lblPitanja.setText("25. Matemati�ke jedna�ine i sve �to ima veze sa brojevima re�avam lako i brzo.");
		}
		
		if(status==25) 
		{
			button_Next[24].setVisible(false);
			button_Next[25].setVisible(true);
			button_Next[25].setText("Next");
			this.lblPitanja.setText("26. Volim da istra�ujem prirodne sile (elektricitet, gravitaciju,...)");
		}
		
		if(status==26) 
		{
			button_Next[25].setVisible(false);
			button_Next[26].setVisible(true);
			button_Next[26].setText("Next");
			this.lblPitanja.setText("27. Privla�i me eksperimentisanje u laboratoriji.");
		}
		
		if(status==27) 
		{
			button_Next[26].setVisible(false);
			button_Next[27].setVisible(true);
			button_Next[27].setText("Next");
			this.lblPitanja.setText("28. Volim da istra�ujem poreklo biljnog i �ivotinjskog sveta.");
		}
		
		if(status==28) 
		{
			button_Next[27].setVisible(false);
			button_Next[28].setVisible(true);
			button_Next[28].setText("Next");
			this.lblPitanja.setText("29. Zanimaju me molekuli, atomi i njihova struktura.");
		}
		
		if(status==29) 
		{
			button_Next[28].setVisible(false);
			button_Next[29].setVisible(true);
			button_Next[29].setText("Next");
			this.lblPitanja.setText("30. Interesuju me uzroci razli�itih prirodnih pojava.");
		}
		
///////////////////////////////////
//PRODAJA
//////////////////////////////////
		
		if(status==30) 
		{
			button_Next[29].setVisible(false);
			button_Next[30].setVisible(true);
			button_Next[30].setText("Next");
			this.lblPitanja.setText("31. U�ivao/la bih u zakazivanju sastanaka, do�ekivanju i ispra�anju klijenata. ");
		}
		
		if(status==31) 
		{
			button_Next[30].setVisible(false);
			button_Next[31].setVisible(true);
			button_Next[31].setText("Next");
			this.lblPitanja.setText("<html> 32. Interesantno mi je da upoznajem kupce sa svojstvima robe i uslovima kupovine.</html>");
		}
		
		if(status==32) 
		{
			button_Next[31].setVisible(false);
			button_Next[32].setVisible(true);
			button_Next[32].setText("Next");
			this.lblPitanja.setText("33. Imam dara za organizaciju ro�endana i proslava.");
		}
		
		if(status==33) 
		{
			button_Next[32].setVisible(false);
			button_Next[33].setVisible(true);
			button_Next[33].setText("Next");
			this.lblPitanja.setText("34. U velikoj meri mi polazi za rukom da uverim ljude u ne�to.");
		}
		
		if(status==34) 
		{
			button_Next[33].setVisible(false);
			button_Next[34].setVisible(true);
			button_Next[34].setText("Next");
			this.lblPitanja.setText("35. Voleo/la bih da komuniciram sa klijentima i vodim ra�una o kvalitetu usluge.");
		}
		
		if(status==35) 
		{
			button_Next[34].setVisible(false);
			button_Next[35].setVisible(true);
			button_Next[35].setText("Next");
			this.lblPitanja.setText("36. Zabavno je baviti se promocijom odre�enih proizvoda.");
		}
		
///////////////////////////////////
// MEDICINA
//////////////////////////////////
		
		if(status==36) 
		{
			button_Next[35].setVisible(false);
			button_Next[36].setVisible(true);
			button_Next[36].setText("Next");
			this.lblPitanja.setText("37. Volim da poma�em drugima.");
		}
		
		if(status==37) 
		{
			button_Next[36].setVisible(false);
			button_Next[37].setVisible(true);
			button_Next[37].setText("Next");
			this.lblPitanja.setText("38. Smiren sam u stresnim situacijama.");
		}
		
		if(status==38) 
		{
			button_Next[37].setVisible(false);
			button_Next[38].setVisible(true);
			button_Next[38].setText("Next");
			this.lblPitanja.setText("39. Spreman sam da preuzmem odgovornost za druge.");
		}
		
		if(status==39) 
		{
			button_Next[38].setVisible(false);
			button_Next[39].setVisible(true);
			button_Next[39].setText("Next");
			this.lblPitanja.setText("40. Voleo/la bih da le�im druge.");
		}
		
		if(status==40) 
		{
			button_Next[39].setVisible(false);
			button_Next[40].setVisible(true);
			button_Next[40].setText("Next");
			this.lblPitanja.setText("41. Interesuje me genetika i rad u laboratoriji.");
		}
		
		if(status==41) 
		{
			button_Next[40].setVisible(false);
			button_Next[41].setVisible(true);
			button_Next[41].setText("Next");
			this.lblPitanja.setText("42. Ne plasim se igle i krvi.");
		}
		
///////////////////////////////////
// POLJOPRIVREDA
//////////////////////////////////
		
		if(status==42) 
		{
			button_Next[41].setVisible(false);
			button_Next[42].setVisible(true);
			button_Next[42].setText("Next");
			this.lblPitanja.setText("43. �esto provodim vreme u prirodi.");
		}
		
		if(status==43) 
		{
			button_Next[42].setVisible(false);
			button_Next[43].setVisible(true);
			button_Next[43].setText("Next");
			this.lblPitanja.setText("44. Volim biljke i �ivotinje.");
		}
		
		if(status==44) 
		{
			button_Next[43].setVisible(false);
			button_Next[44].setVisible(true);
			button_Next[44].setText("Next");
			this.lblPitanja.setText("45. Interesuje me hortikultura.");
		}
		
		if(status==45) 
		{
			button_Next[44].setVisible(false);
			button_Next[45].setVisible(true);
			button_Next[45].setText("Next");
			this.lblPitanja.setText("46. Voleo/la bih da uzgajam razli�ite biljke i �ivotinje.");
		}
		
		if(status==46) 
		{
			button_Next[45].setVisible(false);
			button_Next[46].setVisible(true);
			button_Next[46].setText("Next");
			this.lblPitanja.setText("47. Privla�i me �ivot na selu.");
		}
		
		if(status==47) 
		{
			button_Next[46].setVisible(false);
			button_Next[47].setVisible(true);
			button_Next[47].setText("Zavr�i test");
			this.lblPitanja.setText("48. Interesuje me �umarstvo i ratarstvo.");
		}
	}
	
	public Test() 
	{
		this.button_Next = new JButton[48];
		initialize();
		Change(0);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		String filename1 = "sport.fcl";
		FIS fis1 = FIS.load(filename1, true);

		if (fis1 == null) {
			System.err.println("Can't load file: '" + filename1 + "'");
			System.exit(1);
		}
		
		String filename2 = "umetnost.fcl";
		FIS fis2 = FIS.load(filename2, true);

		if (fis2 == null) {
			System.err.println("Can't load file: '" + filename2 + "'");
			System.exit(1);
		}
		
		String filename3 = "drustvene_nauke.fcl";
		FIS fis3 = FIS.load(filename3, true);

		if (fis3 == null) {
			System.err.println("Can't load file: '" + filename3 + "'");
			System.exit(1);
		}
		
		String filename4 = "tehnika.fcl";
		FIS fis4 = FIS.load(filename4, true);

		if (fis4 == null) {
			System.err.println("Can't load file: '" + filename4 + "'");
			System.exit(1);
		}
		
		String filename5 = "prirodne_nauke.fcl";
		FIS fis5 = FIS.load(filename5, true);

		if (fis5 == null) {
			System.err.println("Can't load file: '" + filename5 + "'");
			System.exit(1);
		}
		
		String filename6 = "prodaja.fcl";
		FIS fis6 = FIS.load(filename6, true);

		if (fis6 == null) {
			System.err.println("Can't load file: '" + filename6 + "'");
			System.exit(1);
		}
		
		String filename7 = "medicina.fcl";
		FIS fis7 = FIS.load(filename7, true);

		if (fis7 == null) {
			System.err.println("Can't load file: '" + filename7 + "'");
			System.exit(1);
		}
		
		String filename8 = "poljoprivreda.fcl";
		FIS fis8 = FIS.load(filename8, true);

		if (fis8 == null) {
			System.err.println("Can't load file: '" + filename8 + "'");
			System.exit(1);
		}

		// Get default function block
		FunctionBlock fb1 = fis1.getFunctionBlock(null);
		FunctionBlock fb2 = fis2.getFunctionBlock(null);
		FunctionBlock fb3 = fis3.getFunctionBlock(null);
		FunctionBlock fb4 = fis4.getFunctionBlock(null);
		FunctionBlock fb5 = fis5.getFunctionBlock(null);
		FunctionBlock fb6 = fis6.getFunctionBlock(null);
		FunctionBlock fb7 = fis7.getFunctionBlock(null);
		FunctionBlock fb8 = fis8.getFunctionBlock(null);
		
		
		frame = new JFrame();
		frame.setTitle("Test profesionalne orjentacije");
		frame.setBounds(100, 100, 619, 428);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//////////////////////////////////////////////////////////////
		//  PANEL ZA PITANJA
		/////////////////////////////////////////////////////////////
		panel1 = new JPanel();
		panel1.setBounds(10, 11, 574, 389);
		panel1.setLayout(null);
		
		lblPitanja = new JLabel("");
		lblPitanja.setBounds(21, 25, 512, 62);
		lblPitanja.setFont(new Font("Tahoma", Font.PLAIN, 14));
		panel1.add(lblPitanja);
		
		lblNewLabel = new JLabel("Uneci ocenu 1-10");
		lblNewLabel.setBounds(21, 93, 127, 17);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		panel1.add(lblNewLabel);
		
		txtOcena = new JTextField();
		txtOcena.setBounds(152, 94, 96, 19);
		txtOcena.setColumns(10);
		panel1.add(txtOcena);
		
		/////////////////////////
		// SPORT
		/////////////////////////
		JButton btn0 = new JButton("Next");
		btn0.setBounds(231, 160, 63, 21);
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb1.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(1);
			}
		});
		panel1.add(btn0);
		button_Next[0]=btn0;
		
		JButton btn1 = new JButton("Next1");
		btn1.setBounds(231, 160, 63, 21);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb1.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(2);
			}
		});
		panel1.add(btn1);
		button_Next[1]=btn1;
		
		JButton btn2 = new JButton("Next2");
		btn2.setBounds(231, 160, 63, 21);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb1.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(3);
			}
		});
		
		panel1.add(btn2);
		button_Next[2]=btn2;
		
		JButton btn3 = new JButton("Next3");
		btn3.setBounds(231, 160, 63, 21);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb1.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(4);
			}
		});
		
		panel1.add(btn3);
		button_Next[3]=btn3;
		
		JButton btn4 = new JButton("Next4");
		btn4.setBounds(231, 160, 63, 21);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb1.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(5);
			}
		});
		
		panel1.add(btn4);
		button_Next[4]=btn4;
		
		JButton btn5 = new JButton("Next5");
		btn5.setBounds(231, 160, 63, 21);
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb1.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				Change(6);     
			}
		});
		panel1.add(btn5);
		button_Next[5]=btn5;
		
/////////////////////////
// UMETNOST
/////////////////////////
		
		JButton btn6 = new JButton("Next6");
		btn6.setBounds(231, 160, 63, 21);
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb2.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(7);
			}
		});
		panel1.add(btn6);
		button_Next[6]=btn6;
		
		JButton btn7 = new JButton("Next7");
		btn7.setBounds(231, 160, 63, 21);
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb2.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(8);
			}
		});
		panel1.add(btn7);
		button_Next[7]=btn7;
		
		JButton btn8 = new JButton("Next8");
		btn8.setBounds(231, 160, 63, 21);
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb2.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(9);
			}
		});
		
		panel1.add(btn8);
		button_Next[8]=btn8;
		
		JButton btn9 = new JButton("Next9");
		btn9.setBounds(231, 160, 63, 21);
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb2.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(10);
			}
		});
		
		panel1.add(btn9);
		button_Next[9]=btn9;
		
		JButton btn10 = new JButton("Next10");
		btn10.setBounds(231, 160, 63, 21);
		btn10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb2.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(11);
			}
		});
		
		panel1.add(btn10);
		button_Next[10]=btn10;
		
		JButton btn11 = new JButton("Next11");
		btn11.setBounds(231, 160, 63, 21);
		btn11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb2.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				Change(12);     
			}
		});
		panel1.add(btn11);
		button_Next[11]=btn11;
		
		
/////////////////////////
// DRUSTVENE NAUKE
/////////////////////////
		
		JButton btn12 = new JButton("Next12");
		btn12.setBounds(231, 160, 63, 21);
		btn12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb3.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(13);
			}
		});
		panel1.add(btn12);
		button_Next[12]=btn12;
		
		JButton btn13 = new JButton("Next13");
		btn13.setBounds(231, 160, 63, 21);
		btn13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb3.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(14);
			}
		});
		panel1.add(btn13);
		button_Next[13]=btn13;
		
		JButton btn14 = new JButton("Next14");
		btn14.setBounds(231, 160, 63, 21);
		btn14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb3.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(15);
			}
		});
		
		panel1.add(btn14);
		button_Next[14]=btn14;
		
		JButton btn15 = new JButton("Next15");
		btn15.setBounds(231, 160, 63, 21);
		btn15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb3.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(16);
			}
		});
		
		panel1.add(btn15);
		button_Next[15]=btn15;
		
		JButton btn16 = new JButton("Next16");
		btn16.setBounds(231, 160, 63, 21);
		btn16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb3.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(17);
			}
		});
		
		panel1.add(btn16);
		button_Next[16]=btn16;
		
		JButton btn17 = new JButton("Next17");
		btn17.setBounds(231, 160, 63, 21);
		btn17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb3.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				Change(18);     
			}
		});
		panel1.add(btn17);
		button_Next[17]=btn17;
		
/////////////////////////
// TEHNIKA
/////////////////////////
		
		JButton btn18 = new JButton("Next18");
		btn18.setBounds(231, 160, 63, 21);
		btn18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb4.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(19);
			}
		});
		panel1.add(btn18);
		button_Next[18]=btn18;
		
		JButton btn19 = new JButton("Next19");
		btn19.setBounds(231, 160, 63, 21);
		btn19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb4.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(20);
			}
		});
		panel1.add(btn19);
		button_Next[19]=btn19;
		
		JButton btn20 = new JButton("Next20");
		btn20.setBounds(231, 160, 63, 21);
		btn20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb4.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(21);
			}
		});
		
		panel1.add(btn20);
		button_Next[20]=btn20;
		
		JButton btn21 = new JButton("Next21");
		btn21.setBounds(231, 160, 63, 21);
		btn21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb4.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(22);
			}
		});
		
		panel1.add(btn21);
		button_Next[21]=btn21;
		
		JButton btn22 = new JButton("Next22");
		btn22.setBounds(231, 160, 63, 21);
		btn22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb4.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(23);
			}
		});
		
		panel1.add(btn22);
		button_Next[22]=btn22;
		
		JButton btn23 = new JButton("Next23");
		btn23.setBounds(231, 160, 63, 21);
		btn23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb4.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				Change(24);      
			}
		});
		panel1.add(btn23);
		button_Next[23]=btn23;
		
/////////////////////////
// PRIRODNE NAUKE
/////////////////////////
		
		JButton btn24 = new JButton("Next24");
		btn24.setBounds(231, 160, 63, 21);
		btn24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb5.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(25);
			}
		});
		panel1.add(btn24);
		button_Next[24]=btn24;
		
		JButton btn25 = new JButton("Next25");
		btn25.setBounds(231, 160, 63, 21);
		btn25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb5.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(26);
			}
		});
		panel1.add(btn25);
		button_Next[25]=btn25;
		
		JButton btn26 = new JButton("Next26");
		btn26.setBounds(231, 160, 63, 21);
		btn26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb5.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(27);
			}
		});
		
		panel1.add(btn26);
		button_Next[26]=btn26;
		
		JButton btn27 = new JButton("Next27");
		btn27.setBounds(231, 160, 63, 21);
		btn27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb5.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(28);
			}
		});
		
		panel1.add(btn27);
		button_Next[27]=btn27;
		
		JButton btn28 = new JButton("Next28");
		btn28.setBounds(231, 160, 63, 21);
		btn28.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb5.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(29);
			}
		});
		
		panel1.add(btn28);
		button_Next[28]=btn28;
		
		JButton btn29 = new JButton("Next29");
		btn29.setBounds(231, 160, 63, 21);
		btn29.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb5.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				Change(30);      
			}
		});
		panel1.add(btn29);
		button_Next[29]=btn29;
		
/////////////////////////
// PRODAJA
/////////////////////////
		
		JButton btn30 = new JButton("Next30");
		btn30.setBounds(231, 160, 63, 21);
		btn30.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb6.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(31);
			}
		});
		panel1.add(btn30);
		button_Next[30]=btn30;
		
		JButton btn31 = new JButton("Next31");
		btn31.setBounds(231, 160, 63, 21);
		btn31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb6.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(32);
			}
		});
		panel1.add(btn31);
		button_Next[31]=btn31;
		
		JButton btn32 = new JButton("Next32");
		btn32.setBounds(231, 160, 63, 21);
		btn32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb6.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(33);
			}
		});
		
		panel1.add(btn32);
		button_Next[32]=btn32;
		
		JButton btn33 = new JButton("Next33");
		btn33.setBounds(231, 160, 63, 21);
		btn33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb6.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(34);
			}
		});
		
		panel1.add(btn33);
		button_Next[33]=btn33;
		
		JButton btn34 = new JButton("Next34");
		btn34.setBounds(231, 160, 63, 21);
		btn34.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb6.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(35);
			}
		});
		
		panel1.add(btn34);
		button_Next[34]=btn34;
		
		JButton btn35 = new JButton("Next35");
		btn35.setBounds(231, 160, 63, 21);
		btn35.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb6.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				Change(36);     
			}
		});
		panel1.add(btn35);
		button_Next[35]=btn35;
		
/////////////////////////
// MEDICINA
/////////////////////////
		
		JButton btn36 = new JButton("Next36");
		btn36.setBounds(231, 160, 63, 21);
		btn36.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb7.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(37);
			}
		});
		panel1.add(btn36);
		button_Next[36]=btn36;
		
		JButton btn37 = new JButton("Next37");
		btn37.setBounds(231, 160, 63, 21);
		btn37.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb7.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(38);
			}
		});
		panel1.add(btn37);
		button_Next[37]=btn37;
		
		JButton btn38 = new JButton("Next38");
		btn38.setBounds(231, 160, 63, 21);
		btn38.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb7.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(39);
			}
		});
		
		panel1.add(btn38);
		button_Next[38]=btn38;
		
		JButton btn39 = new JButton("Next39");
		btn39.setBounds(231, 160, 63, 21);
		btn39.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb7.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(40);
			}
		});
		
		panel1.add(btn39);
		button_Next[39]=btn39;
		
		JButton btn40 = new JButton("Next40");
		btn40.setBounds(231, 160, 63, 21);
		btn40.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb7.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(41);
			}
		});
		
		panel1.add(btn40);
		button_Next[40]=btn40;
		
		JButton btn41 = new JButton("Next41");
		btn41.setBounds(231, 160, 63, 21);
		btn41.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb7.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				Change(42);     
			}
		});
		panel1.add(btn41);
		button_Next[41]=btn41;
		
/////////////////////////
// POLJOPRIVREDA
/////////////////////////
		
		JButton btn42 = new JButton("Next42");
		btn42.setBounds(231, 160, 63, 21);
		btn42.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb8.setVariable("answer_1", Double.parseDouble(txtOcena.getText()));
				Change(43);
			}
		});
		panel1.add(btn42);
		button_Next[42]=btn42;
		
		JButton btn43 = new JButton("Next43");
		btn43.setBounds(231, 160, 63, 21);
		btn43.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb8.setVariable("answer_2", Double.parseDouble(txtOcena.getText()));
				Change(44);
			}
		});
		panel1.add(btn43);
		button_Next[43]=btn43;
		
		JButton btn44 = new JButton("Next44");
		btn44.setBounds(231, 160, 63, 21);
		btn44.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb8.setVariable("answer_3", Double.parseDouble(txtOcena.getText()));
				Change(45);
			}
		});
		
		panel1.add(btn44);
		button_Next[44]=btn44;
		
		JButton btn45 = new JButton("Next45");
		btn45.setBounds(231, 160, 63, 21);
		btn45.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb8.setVariable("answer_4", Double.parseDouble(txtOcena.getText()));
				Change(46);
			}
		});
		
		panel1.add(btn45);
		button_Next[45]=btn45;
		
		JButton btn46 = new JButton("Next46");
		btn46.setBounds(231, 160, 63, 21);
		btn46.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb8.setVariable("answer_5", Double.parseDouble(txtOcena.getText()));
				Change(47);
			}
		});
		
		panel1.add(btn46);
		button_Next[46]=btn46;
		
		JButton btn47 = new JButton("Next47");
		btn47.setBounds(231, 160, 93, 21);
		btn47.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fb8.setVariable("answer_6", Double.parseDouble(txtOcena.getText()));
				fb1.evaluate();
				fb1.getVariable("sport").defuzzify();
				fb2.evaluate();
				fb2.getVariable("umetnost").defuzzify();
				fb3.evaluate();
				fb3.getVariable("drustvene_nauke").defuzzify();
				fb4.evaluate();
				fb4.getVariable("tehnika").defuzzify();
				fb5.evaluate();
				fb5.getVariable("prirodne_nauke").defuzzify();
				fb6.evaluate();
				fb6.getVariable("prodaja").defuzzify();
				fb7.evaluate();
				fb7.getVariable("medicina").defuzzify();
				fb8.evaluate();
				fb8.getVariable("poljoprivreda").defuzzify();
				JOptionPane.showMessageDialog(btn47, "<html>Sport: " + fb1.getVariable("sport").getValue() + "<br>"
						+ "Umetnost: " + fb2.getVariable("umetnost").getValue() + "<br>"
						+ "Dru�tvene nauke " + fb3.getVariable("drustvene_nauke").getValue() + "<br>"
						+ "Tehnika i tehnologija: " + fb4.getVariable("tehnika").getValue() + "<br>"
						+ "Prirodne nauke: " + fb5.getVariable("prirodne_nauke").getValue() + "<br>"
						+ "Prodaja i uslu�ne delatnosti: " + fb6.getVariable("prodaja").getValue() + "<br>"
						+ "Medicina: " + fb7.getVariable("medicina").getValue() + "<br>"
						+ "Poljoprivreda: " + fb8.getVariable("poljoprivreda").getValue() + "</html>");      
			}
		});
		panel1.add(btn47);
		button_Next[47]=btn47;
		
		
		
		//////////////////////////////////////////////////////////////
		// POCETNI PANEL
		//////////////////////////////////////////////////////////////
		panel = new JPanel();
		panel.setBounds(10, 11, 574, 389);
        frame.getContentPane().add(panel);
		
		lblNaslov = new JLabel("Test profesionalne orjentacije");
		lblNaslov.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		lblOpis = new JLabel("<html>Ovaj test sadr�i razli�ite stavove i tvrdnje, a Va� zadatak je procenite u kojoj meri volite navedene aktivnosti, odnosno koliko se na Vas odnose navedene tvrdnje na skali od 1 do 10. Jedan je najni�a ocena, a deset je najvi�a. Na kraju testa, dobi�ete informaciju koja profesionalna oblast Vam najvi�e odgovara.<html>");
		lblOpis.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		btnStart = new JButton("Zapo�ni test");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				frame.remove(panel);
				frame.getContentPane().add(panel1);
                frame.validate();
                frame.repaint();
			}
		});
		btnStart.setFont(new Font("Tahoma", Font.PLAIN, 14));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(236)
							.addComponent(btnStart, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(195)
							.addComponent(lblNaslov))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(101)
							.addComponent(lblOpis, GroupLayout.PREFERRED_SIZE, 388, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(116, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(24)
					.addComponent(lblNaslov, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
					.addGap(36)
					.addComponent(lblOpis, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)
					.addGap(32)
					.addComponent(btnStart, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(124, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);	
	}
}
